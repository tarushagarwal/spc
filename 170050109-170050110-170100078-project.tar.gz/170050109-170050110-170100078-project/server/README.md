Secure Personal Cloud
(server)

You are provided the compressed django code base for the server 'spc.zip'

Run the serverscript.sh before proceeding

extract and run the django server (We did it on pycharm proffesional edition : open the spc folder obtained from extracting spc.zip in pychar , set python interpreter as python3+ and add a django server as the configuration with whatever name and url you desire)

You will get the url on terminal when the server is running 

Enter this url for client (Please note: do not give any '/' after the url. Ex you can see : 'http://127.0.0.1:8000')

Kindly make sure that the database is empty if you find any unknown error while running the server

