#!/bin/sh
pip install django-db-file-storage
pip install djangorestframework
pip install django-cleanup
pip install api
pip install requests
pip install pycrypto