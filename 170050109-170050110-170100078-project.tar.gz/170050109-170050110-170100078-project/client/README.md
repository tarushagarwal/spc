Secure Personal Cloud
(client)

Copy the given folder 170050109proj to the root directory such that /170050109proj is a directory in your system now
Run the script clientscript.sh

Now you can use 'spc' as a terminal command 

Before proceeding make sure the server is active 

First set the server-url using
spc --server set-url command

Now configure your username and password using
spc --config edit

You are now free to choose any directory you want to upload ( Multiple directory observe support )

Kindly fill full path or relative path to the current directory whenever asked for 'Folder name: ' during your operations

To make the man page run 'help2man spc' and then put the output in the man directory so that you can run man spc
If help2man is not installed , install it

Example of Usage:

input-spc --server set-url
output-URL:
input- 127.0.0.1:8000

spc --config edit
'Username : ' ...
...

spc --observe
'Folder name' ...

spc --status
'Folder name: ' ...

spc --sync
'Folder name' ...

spc --periodicsync
'Folder name' ...

spc --ende list

spc --ende dump
'File path:' ...

spc --ende update

spc --version

spc --help





FOR WEB CLIENT::

just visit your url + '/cloud'

Eg: 'http://127.0.0.1:8000/cloud'

