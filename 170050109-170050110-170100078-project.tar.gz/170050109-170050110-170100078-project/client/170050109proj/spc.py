from Crypto.Cipher import AES
from Crypto.PublicKey import RSA
from Crypto.Cipher import DES3
import click
import getpass
import requests
import os,struct,random
from bs4 import BeautifulSoup
import sys
import json
import hashlib
import multiprocessing
import time
from Crypto.Cipher import ARC4
from Crypto.Hash import SHA
from Crypto.Random import get_random_bytes
import subprocess
# from crontab import CronTab

# un="admin"
# pw="admin"

if os.path.exists("/170050109proj/170050109spctest.txt"):
	global un,pw
	with open("/170050109proj/170050109spctest.txt", "r") as f:
		un = f.readline().strip()
		pw = f.readline().strip()
		# print(un)
if os.path.exists("/170050109proj/170050109spcurl.txt"):
	global myurl
	with open("/170050109proj/170050109spcurl.txt", "r") as f:
		myurl = f.readline().strip()



def log(un,pw):
	URL = myurl+'/cloud/accounts/login/'

	client = requests.session()

	# Retrieve the CSRF token first
	client.get(URL)  # sets cookie
	if 'csrftoken' in client.cookies:
		# Django 1.6 and up
		csrftoken = client.cookies['csrftoken']
	else:
		# older versions
		csrftoken = client.cookies['csrf']
	# print(csrftoken)
	login_data = dict(username=un, password=pw, csrfmiddlewaretoken=csrftoken)
	r = client.post(URL, data=login_data, params=dict(Referer=URL))
	# print(r.text)
	soup=BeautifulSoup(r.text,'html.parser')

	names=soup.find_all('a')
	if names==[]:
		print('incorrect')
		sys.exit()
	for x in names:

		if str(x)=='<a href="/cloud/upload/">upload</a>':
			print('correct')
			return True
		else:
			print('incorrect')
			return False
	return r

#############################

def encAES(key, in_filename, out_filename=None, chunksize=64*1024):
	if not out_filename:
		out_filename = in_filename + '.enc'

	iv = os.urandom(16)
	encryptor = AES.new(key, AES.MODE_CBC, iv)
	filesize = os.path.getsize(in_filename)

	with open(in_filename, 'rb') as infile:
		with open(out_filename, 'wb') as outfile:
			outfile.write(struct.pack('<Q', filesize))
			outfile.write(iv)
			x=bytes(' ', 'utf-8')

			while True:
				chunk = infile.read(chunksize)
				if len(chunk) == 0:
					break
				elif len(chunk) % 16 != 0:
					chunk += x * (16 - len(chunk) % 16)

				outfile.write(encryptor.encrypt(chunk))

	return out_filename

def dcypAES(key, in_filename, out_filename=None, chunksize=24*1024):
	if not out_filename:
		out_filename = os.path.splitext(in_filename)[0]

	with open(in_filename, 'rb') as infile:
		origsize = struct.unpack('<Q', infile.read(struct.calcsize('Q')))[0]
		iv = infile.read(16)
		decryptor = AES.new(key, AES.MODE_CBC, iv)

		with open(out_filename, 'wb') as outfile:
			while True:
				chunk = infile.read(chunksize)
				if len(chunk) == 0:
					break
				outfile.write(decryptor.decrypt(chunk))

			outfile.truncate(origsize)

	return out_filename

###################################################

def encDES(key, in_filename, out_filename=None, chunksize=64*1024):
	if not out_filename:
		out_filename = in_filename + '.enc'

	iv = os.urandom(8)
	encryptor = DES3.new(key, DES3.MODE_OFB, iv)
	filesize = os.path.getsize(in_filename)

	with open(in_filename, 'rb') as infile:
		with open(out_filename, 'wb') as outfile:
			outfile.write(struct.pack('<Q', filesize))
			outfile.write(iv)
			x=bytes(' ', 'utf-8')

			while True:
				chunk = infile.read(chunksize)
				if len(chunk) == 0:
					break
				elif len(chunk) % 8 != 0:
					chunk += x * (8 - len(chunk) % 8)

				outfile.write(encryptor.encrypt(chunk))

	return out_filename

def dcypDES(key, in_filename, out_filename=None, chunksize=24*1024):
	if not out_filename:
		out_filename = os.path.splitext(in_filename)[0]

	with open(in_filename, 'rb') as infile:
		origsize = struct.unpack('<Q', infile.read(struct.calcsize('Q')))[0]
		iv = infile.read(8)
		decryptor = DES3.new(key, DES3.MODE_OFB, iv)

		with open(out_filename, 'wb') as outfile:
			while True:
				chunk = infile.read(chunksize)
				if len(chunk) == 0:
					break
				outfile.write(decryptor.decrypt(chunk))

			outfile.truncate(origsize)

	return out_filename
#############################################

def encARC(key, in_filename, out_filename=None, chunksize=64*1024):

	
	if not out_filename:
		out_filename = in_filename + '.enc'

	with open(in_filename, 'rb') as infile:
		with open(out_filename, 'wb') as outfile:
			obj1 = ARC4.new(key)
			obj2 = ARC4.new(key)
			text = infile.read()
			cipher_text = obj1.encrypt(text)
			# print(cipher_text)
			outfile.write(cipher_text)
			# print(obj2.decrypt(cipher_text))


	return out_filename

def dcypARC(key, in_filename, out_filename=None, chunksize=24*1024):
	if not out_filename:
		out_filename = os.path.splitext(in_filename)[0]
	# with open('/170050109proj/170050109spc/170050109proj/170050109spcscheme.txt', 'r') as f:
	# 	ke=f.readline().strip()
	# 	keyy=f.readline().strip()

	with open(in_filename, 'rb') as infile:
		data=infile.read()
		# print(data)
		# print(type(data))
		# data=b'\x10\x04\xaf\xdd"\x18\x16h\xa4\x9b,\x8d'
		# print(data)
		# print(type(data))
		obj2 = ARC4.new(key)
		with open(out_filename, 'wb') as outfile:
			outfile.write(obj2.decrypt(data))


	return out_filename


#############################################
#generating md5
def file_as_bytes(file):
	with file:
		return file.read()


#Upload structure
def create_main(fname):
	global un,pw
	a=myurl+'/cloud/'+"createfolder/"
	folderdata=dict(username=un,password=pw,folder_name=os.path.basename(fname))
	rr = requests.post(a,data=folderdata)
	data=json.loads(rr.text)
	# print(data) 
	r=requests.get(myurl+"/cloud/synccreate/?username="+un+"&password="+pw+"&parent="+str(os.path.basename(fname)))
	# print(json.loads(r.text))


def create_folder(fname,pname):
	global un,pw
	a=myurl+'/cloud/'+"createfolder/"
	folderdata=dict(username=un,password=pw, parent=os.path.basename(pname), folder_name=os.path.basename(fname))
	rr = requests.post(a,data=folderdata)
	data=json.loads(rr.text)
	# print(data) 

# def upload_file(fname,pname):
# 	a=myurl+'/cloud/'+"upload/"
# 	files={'file_data': open(fname,'rb')}
# 	md5sum=hashlib.md5(file_as_bytes(open(fname, 'rb'))).hexdigest()
# 	folderdata=dict(username=un,password=pw, parent=os.path.basename(pname), name=os.path.basename(fname), md5=md5sum)
# 	rr = requests.post(a, files=files, data=folderdata)
# 	data=json.loads(rr.text)
# 	print(data) 

def upload_file(fname,pname):
	global un,pw
	a=myurl+'/cloud/'+"upload/"
	md5sum=hashlib.md5(file_as_bytes(open(fname,'rb'))).hexdigest()
	# encrypted_file=encAES(fname)
	# un='admin'
	# pw ='admin'
	# encrypted_file=fname
	with open('/170050109proj/170050109spcscheme.txt', 'r') as f:
		schema = f.readline().strip()
		if schema=='AES':
			key=f.readline().strip()
			encrypted_file=encAES(key, fname)
		elif schema=='DES':
			key=f.readline().strip()
			encrypted_file=encDES(key, fname)
			# print(encrypted_file)
		elif schema=="ARC4":
			key=f.readline().strip()
			encrypted_file=encARC(key, fname)

	files={'file_data': open(encrypted_file,'rb')}
	# print(type(files[file_data]))
	folderdata=dict(username=un,password=pw, parent=os.path.basename(pname), name=os.path.basename(fname), md5=md5sum)
	rr = requests.post(a, files=files, data=folderdata)
	data=json.loads(rr.text)
	print(os.path.basename(fname),data['status'])
	os.remove(encrypted_file)


#main upload function
def upload(curr,prev):
	if os.path.isfile(curr):   
		upload_file(curr,prev)

	elif os.path.isdir(curr):
		create_folder(curr,prev)
		for filename in os.listdir(curr):
			upload(curr+"/"+str(filename),curr)


def download(file_id,curr):
	global un,pw
	data=requests.get(myurl+'/cloud/download/?username='+str(un)+'&password='+str(pw)+'&file_id='+str(file_id))
	file=json.loads(data.text)
	if not 'failed' in file:
		# print(file['link'])
		r=requests.get(myurl+'/files/download/?name='+str(file['link']), allow_redirects=True)
		# if file['link'].find('/'):
		# 	filename=file['link'].split('/')[4]
		xx=file['name']

		open(curr+"/"+file['name']+".enc", 'wb').write(r.content)
		with open('/170050109proj/170050109spcscheme.txt', 'r') as f:
			schema = f.readline().strip()
			if schema=='AES':
				key=f.readline().strip()
				# encrypted_file=encAES(key, fname)
				dcypAES(key, curr+"/"+file['name']+".enc",curr+"/"+xx)
			if schema=='DES':
				key=f.readline().strip()
				dcypDES(key,curr+"/"+file['name']+".enc",curr+"/"+xx)
			if schema=="ARC4":
			
				key=f.readline().strip()
				dcypARC(key,curr+"/"+file['name']+".enc",curr+"/"+xx)
		
		os.remove(curr+"/"+file['name']+".enc")
		print(xx,'downloaded')
	else:
		print('Failed')

###################################################
def change_key(p,x,sc):
	x=hashlib.md5(x.encode('utf-8')).hexdigest()
	requests.get(myurl+"/cloud/changekey/?username="+un+"&password="+pw+"&parent="+str(p)+"&key="+str(x)+"&schema="+str(sc))


def key_status(p):
	r=requests.get(myurl+"/cloud/syncstatus/?username="+un+"&password="+pw+"&parent="+str(p))
	return(json.loads(r.text))

def sync_status(p):
	r=requests.get(myurl+"/cloud/syncstatus/?username="+un+"&password="+pw+"&parent="+str(p))
	stat=json.loads(r.text)
	if (stat['status']=='no' or (time.time()-float(stat['time']))>120):
		return True
	else:
		return False

def change_status(p,x):
	requests.get(myurl+"/cloud/changestatus/?username="+un+"&password="+pw+"&change="+x+"&parent="+str(p))

def sync_function(curr,pid):
	# print(curr)
	# print(pid)
	if pid==-1:
		files_req=requests.get(myurl+"/cloud/syncfiles/?username="+un+"&password="+pw+"&folder_name="+str(os.path.basename(curr)))
		folders_req=requests.get(myurl+"/cloud/syncfolders/?username="+un+"&password="+pw+"&folder_name="+str(os.path.basename(curr)))
	else:
		files_req=requests.get(myurl+"/cloud/syncfiles/?username="+un+"&password="+pw+"&folder_name="+str(os.path.basename(curr))+"&parent="+str(pid))
		folders_req=requests.get(myurl+"/cloud/syncfolders/?username="+un+"&password="+pw+"&folder_name="+str(os.path.basename(curr))+"&parent="+str(pid))
	files_list=json.loads(files_req.text)
	folders_list=json.loads(folders_req.text)
	# print(files_list)
	# print(folders_list)
	files_done=[]
	folders_done=[]
	for item in files_list:
		fname=item['name']
		# print(fname)
		if os.path.isfile(curr+'/'+fname):
			md5sum=hashlib.md5(file_as_bytes(open(curr+'/'+fname, 'rb'))).hexdigest()
			if not md5sum==item['md5']:
				# print('check fail')
				# print(fname)
				# ask=input("change spc or pc (1/2): ")
				if ask=='1':
					delete_file(item['id'])
					upload_file(curr+'/'+fname,curr)
				else:
					# print('donwloading check sum fail',fname)
					download(item['id'],curr)
		else:
			# print('downloading not present',fname)
			download(item['id'],curr)
		files_done.append(fname)

	for item in folders_list:
		fname=item['folder_name']
		# print(fname)
		if not os.path.isdir(curr+'/'+fname):
			# print(fname)
			# print('working on it')
			# create_folder(curr+'/'+fname,curr)
			os.mkdir(curr+'/'+fname)
			sync_function(curr+'/'+fname,item['parent'])
			# download_folder(pname+'/'+fname,pname)
		else:
			# print('syncing')
			sync_function(curr+'/'+fname,item['parent'])
		folders_done.append(fname)
	# print(folders_done)
	# print(os.listdir(curr))
	for name in os.listdir(curr):
		# print(os.path.isfile(curr+'/'+name) , name)
		if os.path.isfile(curr+'/'+name):
			if not name in files_done:
				# print('uploading')
				upload_file(curr+'/'+name,curr)
		elif os.path.isdir(curr+'/'+name):
			if not name in folders_done:
				# print('upload function',name)
				upload(curr+'/'+name,curr)


###################################################

def delete_file(id):
	# r=requests.get(myurl+"/cloud/deletefile/?username="+un+"&password="+pw+"&name="+str(name)+"&parent="+str(par))
	r=requests.get(myurl+"/cloud/deletefile/?username="+un+"&password="+pw+"&id="+str(id))
	# print(json.loads(r.text))

def delete_folder(par,name):
	r=requests.get(myurl+"/cloud/deletefolder/?username="+un+"&password="+pw+"&name="+str(name)+"&parent="+str(par))
	# print(json.loads(r.text))
def delete_main(name):
	r=requests.get(myurl+"/cloud/deletemain/?username="+un+"&password="+pw+"&name="+str(name))

###################################################

def status_function(curr,pid,basecurr):
	# print(curr)
	# print(pid)
	if pid==-1:
		files_req=requests.get(myurl+"/cloud/syncfiles/?username="+un+"&password="+pw+"&folder_name="+str(os.path.basename(curr)))
		folders_req=requests.get(myurl+"/cloud/syncfolders/?username="+un+"&password="+pw+"&folder_name="+str(os.path.basename(curr)))
	else:
		files_req=requests.get(myurl+"/cloud/syncfiles/?username="+un+"&password="+pw+"&folder_name="+str(os.path.basename(curr))+"&parent="+str(pid))
		folders_req=requests.get(myurl+"/cloud/syncfolders/?username="+un+"&password="+pw+"&folder_name="+str(os.path.basename(curr))+"&parent="+str(pid))
	files_list=json.loads(files_req.text)
	folders_list=json.loads(folders_req.text)
	# print(files_list)
	# print(folders_list)
	files_done=[]
	folders_done=[]
	
	for item in files_list:
		fname=item['name']
		# print(fname)
		if os.path.isfile(curr+'/'+fname):
			md5sum=hashlib.md5(file_as_bytes(open(curr+'/'+fname, 'rb'))).hexdigest()
			if not md5sum==item['md5']:
				files_diff.append(basecurr+'/'+fname)
			else:
				files_common.append(basecurr+'/'+fname)
		else:
			files_spc.append(basecurr+'/'+fname)
		files_done.append(fname)

	for item in folders_list:
		fname=item['folder_name']
		# print(fname)
		if not os.path.isdir(curr+'/'+fname):
			files_spc.append('dir : '+basecurr+'/'+fname)
			# status_function(curr+'/'+fname,item['parent'],basecurr+'/'+fname)
		else:
			status_function(curr+'/'+fname,item['parent'],basecurr+'/'+fname)
		folders_done.append(fname)
	# print(folders_done)
	# print(os.listdir(curr))
	for name in os.listdir(curr):
		# print(os.path.isfile(curr+'/'+name) , name)
		if os.path.isfile(curr+'/'+name):
			if not name in files_done:
				files_pc.append(basecurr+'/'+name)
		elif os.path.isdir(curr+'/'+name):
			if not name in folders_done:
				files_pc.append('dir : '+basecurr+'/'+name)


###################################
@click.command()
@click.option('--version', is_flag=True, help="Will print version")
# @click.option('--testing', is_flag=True, help="Will create folder")
@click.option('--ende',help="encrypt")
@click.option('--observe',is_flag=True,help="observe directory")
# @click.option('--observe',type=str)
@click.option('--sync',is_flag=True,help="sync directory")
@click.option('--status',is_flag=True,help="staus of sync")
# @click.option('--server')
@click.option('--testt',is_flag=True,help="test")
@click.option('--config', help="configure the authentication details using '--config edit'")
@click.option('--periodicsync',is_flag=True,help="start sync")
@click.option('--stopsync',is_flag=True,help="stop sync")
@click.option('--syncforcron',is_flag=True,help="sync directory")
@click.option('--server',help="enter the url")
def say_hello(version,config,sync,ende,observe,testt,status,periodicsync,stopsync,syncforcron,server):
	# glo
	if version:
		click.echo("0.1")

	if server=='set-url':
		myurl=input("server-url : ")
		
		fn=os.path.abspath('/170050109proj/170050109spcurl.txt')

		with open(fn, "w") as f:
			# un = un.strip()
			f.write(myurl+'\n')
			f.close()

	if periodicsync:
		global ask
		# my_cron = CronTab(user='rachitbansal')
		# # for job in my_cron:
		# # 	print(job)
		# # job = my_cron.new(command='python3 /Users/rachitbansal/pro/writedate.py')
		# # # for job in my_cron:
		# # # 	print(job)
		# # job.minute.every(1)
		# my_cron.remove_all()
		# my_cron.write()
		fn1=input('Folder Name: ')
		ask=input("change spc or pc wheck md5 check fails(1/2): ")
		fn=os.path.abspath(fn1)
		with open('/170050109proj/formycron.txt','w') as f:
			f.write(fn+'\n')
			f.write(ask)
		subprocess.call("/170050109proj/see.sh")

	if stopsync:
		subprocess.call("/170050109proj/stop.sh")

	if sync:
		# change_status('no')
		# global ask
		
		fn1=input('Folder Name: ')
		ask=input("change spc or pc wheck md5 check fails(1/2): ")
		fn=os.path.abspath(fn1)
		if not sync_status(os.path.basename(fn)):
			print('Kindly wait for some time')
			sys.exit()

		change_status(os.path.basename(fn),'yes')
		p = multiprocessing.Process(target=sync_function, name="sync", args=(fn,-1,))
		# sync_function(fn,-1)
		p.start()
		p.join(120)
		if p.is_alive():
			p.terminate()
			p.join()
		change_status(os.path.basename(fn),'no')


	if syncforcron:
	# change_status('no')
	# global ask
	# ask=1
	# fn='/Users/rachitbansal/pro/upload'
	# fn=os.path.abspath(fn)
		fn=''
		ask=1
		with open('/170050109proj/formycron.txt','w') as f:
			fn=f.readline().strip()
			ask=f.readline().strip()
		if not sync_status(os.path.basename(fn)):
			print('Kindly wait for some time')
			sys.exit()

		change_status(os.path.basename(fn),'yes')
		p = multiprocessing.Process(target=sync_function, name="sync", args=(fn,-1,))
		# sync_function(fn,-1)
		p.start()
		p.join(120)
		if p.is_alive():
			p.terminate()
			p.join()
		change_status(os.path.basename(fn),'no')



	if status:
		global files_common,files_diff,files_spc,files_pc
		files_common=[]
		files_spc=[]
		files_pc=[]
		files_diff=[]
		fn1=input('Folder Name: ')
		fn=os.path.abspath(fn1)
		status_function(fn,-1,fn1)
		print('')
		print('Files common to spc and user with same content:')
		print('')
		for x in files_common:
			print('--',x)
		print('')
		print('')
		print('Files common to spc and user with different content:')
		print('')
		for x in files_diff:
			print('--', x)
		print('')
		print('')
		print('Files/Directory present in spc and not user:')
		print('')
		for x in files_spc:
			print('--',x)
		print('')
		print('')
		print('Files/Directory present with user and not spc:')
		print('')
		for x in files_pc:
			print('--',x)
		print('')
		print('')


	if observe:
		
		fn=input('Folder Name: ')
		fn=os.path.abspath(fn)
		with open("/170050109proj/170050109spcscheme.txt", "w") as f:
			f.write('AES'+'\n')
			f.write('1234567890123456')
			f.close()
		create_main(fn)
		for filename in os.listdir(fn):
			upload(fn+"/"+str(filename),fn)


	if config=='edit':
		un=input("Username:")
		pw = getpass.getpass('Password:')
		cpw=getpass.getpass('Confirm Password:')
		if pw!=cpw:
			click.echo("Password is not confirmed correctly")
			sys.exit()
		r=log(un,pw)
		if r:
			fn=os.path.abspath('/170050109proj/170050109spctest.txt')

			with open(fn, "w") as f:
				# un = un.strip()
				f.write(un+'\n')
				f.write(pw)
				f.close()

	if ende=='list':
		print('AES : Enter a key of multiple of 16 characters')
		print('ARC4 : Enter any string')
		print('DES : Enter a key of multiples of 8 characters')



	if ende=='dump':
		fn1=input('Folder Name: ')
		fn=os.path.abspath(fn1)
		fnme=os.path.basename(fn)
		dumpfile=input('Dump File Name: ')
		with open(os.path.abspath(dumpfile), "r") as f:
			newschema=f.readline().strip()
			newkey=f.readline().strip()
		

		xx=key_status(fnme)
		serverschema=xx['schema']
		serverkey=xx['key']
		hashkey=hashlib.md5(newkey.encode('utf-8')).hexdigest()
		with open("/170050109proj/170050109spcscheme.txt", "r") as f:
			oldschema=f.readline().strip()
			oldkey=f.readline().strip()
		

		if newschema==serverschema and hashkey==serverkey:
			# print('yes')	
			with open("/170050109proj/170050109spcscheme.txt", "w") as f:
				f.write(newschema+'\n')
				f.write(newkey)
			
			ask=1
			if not sync_status(os.path.basename(fn)):
				print('Kindly wait for some time')
				sys.exit()

			change_status(os.path.basename(fn),'yes')
			p = multiprocessing.Process(target=sync_function, name="sync", args=(fn,-1,))
			# sync_function(fn,-1)
			p.start()
			p.join(120)
			if p.is_alive():
				p.terminate()
				p.join()
			change_status(os.path.basename(fn),'no')


		else:
			delete_main(fnme)
			create_main(fnme)
			for filename in os.listdir(fn):
				upload(fn+"/"+str(filename),fn)
			change_key(os.path.basename(fn),newkey,newschema)



	if ende=='update':
		fn1=input('Folder Name: ')
		fn=os.path.abspath(fn1)
		fnme=os.path.basename(fn)
		# serverschema=input("Current Schema on database: ")
		# serverkey=input("Current Key for database: ")
		xx=key_status(fnme)
		serverschema=xx['schema']
		serverkey=xx['key']

		newschema=input("New schema : ")
		newkey=input("Key: ")

		# m = hashlib.md5()
		# m.update(str(newkey))
		# hashkey=m.hexdigest()
		hashkey=hashlib.md5(newkey.encode('utf-8')).hexdigest()
		with open("/170050109proj/170050109spcscheme.txt", "r") as f:
			oldschema=f.readline().strip()
			oldkey=f.readline().strip()
		

		if newschema==serverschema and hashkey==serverkey:
			# print('yes')	
			with open("/170050109proj/170050109spcscheme.txt", "w") as f:
				f.write(newschema+'\n')
				f.write(newkey)
			
			ask=1
			if not sync_status(os.path.basename(fn)):
				print('Kindly wait for some time')
				sys.exit()

			change_status(os.path.basename(fn),'yes')
			p = multiprocessing.Process(target=sync_function, name="sync", args=(fn,-1,))
			# sync_function(fn,-1)
			p.start()
			p.join(120)
			if p.is_alive():
				p.terminate()
				p.join()
			change_status(os.path.basename(fn),'no')


		else:
			delete_main(fnme)
			create_main(fnme)
			for filename in os.listdir(fn):
				upload(fn+"/"+str(filename),fn)
			change_key(os.path.basename(fn),newkey,newschema)


		# with open("/170050109proj/170050109spcscheme.txt", "w") as f:
		# 	f.write(serverschema+'\n')
		# 	f.write(serverkey)
		
		# ask=1
		# if not sync_status(os.path.basename(fn)):
		# 	print('Kindly wait for some time')
		# 	sys.exit()

		# change_status(os.path.basename(fn),'yes')
		# p = multiprocessing.Process(target=sync_function, name="sync", args=(fn,-1,))
		# # sync_function(fn,-1)
		# p.start()
		# p.join(120)
		# if p.is_alive():
		# 	p.terminate()
		# 	p.join()
		# change_status(os.path.basename(fn),'no')

		# schema=input("New schema : ")
		# if schema=="ARC4":
		# 	# key = b'Very long and confidential key'
		# 	key=input("Key: ")
		# 	with open("/170050109proj/170050109spcscheme.txt", "w") as f:
		# 	# un = un.strip()
		# 		f.write(schema+'\n')
		# 		# f.write('\n')
		# 		f.write(key)
		# 		# f.write(iv)
		# 		f.close()

		# if schema=='AES':
		# 	key=input("Key: ")
		# 	# iv=input("IV: ")
		# 	with open("/170050109proj/170050109spcscheme.txt", "w") as f:
		# 	# un = un.strip()
		# 		f.write(schema+'\n')
		# 		# f.write('\n')
		# 		f.write(key)
		# 		# f.write(iv)
		# 		f.close()

		# if schema=='DES':
		# 	key=input("Key: ")
		# 	with open("/170050109proj/170050109spcscheme.txt", "w") as f:
		# 	# un = un.strip()
		# 		f.write(schema+'\n')
		# 		# f.write('\n')
		# 		f.write(key)
		# 		# f.write(iv)
		# 		f.close()


		# delete_main(fn)
		# create_main(fn)
		# for filename in os.listdir(fn):
		# 	upload(fn+"/"+str(filename),fn)



	if testt:
		# print(un)
		# print(pw)
		# upload("abc.txt","upload")
		# data=requests.get(myurl+'/cloud/download/?username=admin&password=admin&file_id='+str(file_id))
		# fn=os.path.abspath('upload')
		# download(323,fn)
		# os.mkdir('//170050109proj/170050109spc')
		print('hey')
		# fn=os.path.abspath('//170050109proj/170050109spctest.txt')
		# print(fn)
		# with open('/170050109proj/170050109spc/170050109proj/170050109spcscheme.txt', 'r') as f:
		# 	ke=f.readline().strip()
		# 	key=f.readline().strip()
		# dcypARC(key,'ao.txt_deRruNG.enc.txt')

		# dcypAES('This is a key123','abc.txt_okn7yQ6.enc')
		# dcypDES('This is a key123', 'aaa.txt.enc')
		# encDES('This is a key123', 'aaa.txt')


if __name__ == '__main__':
	# edit_is_defined=0
	say_hello() 

	# mine()
	# print(un)
	# test()



