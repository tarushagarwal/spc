#!/bin/sh
touch crontab.cron

# echo "* * * * * python /Users/rachitbansal/pro/spcfordaemon.py " > crontab.cron
echo "* * * * * /usr/local/bin/python3 /Users/rachitbansal/170050109proj/spcfordaemon.py" > crontab.cron
crontab crontab.cron
