from setuptools import setup

setup(
    name='spc',
    version='0.1',
    py_modules=['spc'],
    install_requires=[
        'Click',
    ],
    entry_points='''
        [console_scripts]
        spc=spc:say_hello
        
    ''',
)
