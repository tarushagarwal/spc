from Crypto.Cipher import AES
from Crypto.PublicKey import RSA
from Crypto.Cipher import DES3
import click
import getpass
import requests
import os,struct,random
from bs4 import BeautifulSoup
import sys
import json
import hashlib
import multiprocessing
import time
from Crypto.Cipher import ARC4
from Crypto.Hash import SHA
from Crypto.Random import get_random_bytes

# un="admin"
# pw="admin"


if os.path.exists("/170050109proj/170050109spctest.txt"):
	global un,pw
	with open("/170050109proj/170050109spctest.txt", "r") as f:
		un = f.readline().strip()
		pw = f.readline().strip()
		# print(un)
if os.path.exists("/170050109proj/170050109spcurl.txt"):
	global myurl
	with open("/170050109proj/170050109spcurl.txt", "r") as f:
		myurl = f.readline().strip()



def log(un,pw):
	URL = myurl+'/cloud/accounts/login/'

	client = requests.session()

	# Retrieve the CSRF token first
	client.get(URL)  # sets cookie
	if 'csrftoken' in client.cookies:
		# Django 1.6 and up
		csrftoken = client.cookies['csrftoken']
	else:
		# older versions
		csrftoken = client.cookies['csrf']
	# print(csrftoken)
	login_data = dict(username=un, password=pw, csrfmiddlewaretoken=csrftoken)
	r = client.post(URL, data=login_data, params=dict(Referer=URL))
	# print(r.text)
	soup=BeautifulSoup(r.text,'html.parser')

	names=soup.find_all('a')
	if names==[]:
		print('incorrect')
		sys.exit()
	for x in names:

		if str(x)=='<a href="/cloud/upload/">upload</a>':
			print('correct')
			return True
		else:
			print('incorrect')
			return False
	return r

#############################

def encAES(key, in_filename, out_filename=None, chunksize=64*1024):
	if not out_filename:
		out_filename = in_filename + '.enc'

	iv = os.urandom(16)
	encryptor = AES.new(key, AES.MODE_CBC, iv)
	filesize = os.path.getsize(in_filename)

	with open(in_filename, 'rb') as infile:
		with open(out_filename, 'wb') as outfile:
			outfile.write(struct.pack('<Q', filesize))
			outfile.write(iv)
			x=bytes(' ', 'utf-8')

			while True:
				chunk = infile.read(chunksize)
				if len(chunk) == 0:
					break
				elif len(chunk) % 16 != 0:
					chunk += x * (16 - len(chunk) % 16)

				outfile.write(encryptor.encrypt(chunk))

	return out_filename

def dcypAES(key, in_filename, out_filename=None, chunksize=24*1024):
	if not out_filename:
		out_filename = os.path.splitext(in_filename)[0]

	with open(in_filename, 'rb') as infile:
		origsize = struct.unpack('<Q', infile.read(struct.calcsize('Q')))[0]
		iv = infile.read(16)
		decryptor = AES.new(key, AES.MODE_CBC, iv)

		with open(out_filename, 'wb') as outfile:
			while True:
				chunk = infile.read(chunksize)
				if len(chunk) == 0:
					break
				outfile.write(decryptor.decrypt(chunk))

			outfile.truncate(origsize)

	return out_filename

###################################################

def encDES(key, in_filename, out_filename=None, chunksize=64*1024):
	if not out_filename:
		out_filename = in_filename + '.enc'

	iv = os.urandom(8)
	encryptor = DES3.new(key, DES3.MODE_OFB, iv)
	filesize = os.path.getsize(in_filename)

	with open(in_filename, 'rb') as infile:
		with open(out_filename, 'wb') as outfile:
			outfile.write(struct.pack('<Q', filesize))
			outfile.write(iv)
			x=bytes(' ', 'utf-8')

			while True:
				chunk = infile.read(chunksize)
				if len(chunk) == 0:
					break
				elif len(chunk) % 8 != 0:
					chunk += x * (8 - len(chunk) % 8)

				outfile.write(encryptor.encrypt(chunk))

	return out_filename

def dcypDES(key, in_filename, out_filename=None, chunksize=24*1024):
	if not out_filename:
		out_filename = os.path.splitext(in_filename)[0]

	with open(in_filename, 'rb') as infile:
		origsize = struct.unpack('<Q', infile.read(struct.calcsize('Q')))[0]
		iv = infile.read(8)
		decryptor = DES3.new(key, DES3.MODE_OFB, iv)

		with open(out_filename, 'wb') as outfile:
			while True:
				chunk = infile.read(chunksize)
				if len(chunk) == 0:
					break
				outfile.write(decryptor.decrypt(chunk))

			outfile.truncate(origsize)

	return out_filename
#############################################

def encARC(key, in_filename, out_filename=None, chunksize=64*1024):

	
	if not out_filename:
		out_filename = in_filename + '.enc'

	with open(in_filename, 'rb') as infile:
		with open(out_filename, 'wb') as outfile:
			obj1 = ARC4.new(key)
			obj2 = ARC4.new(key)
			text = infile.read()
			cipher_text = obj1.encrypt(text)
			# print(cipher_text)
			outfile.write(cipher_text)
			# print(obj2.decrypt(cipher_text))


	return out_filename

def dcypARC(key, in_filename, out_filename=None, chunksize=24*1024):
	if not out_filename:
		out_filename = os.path.splitext(in_filename)[0]
	# with open('170050109spc170050109spcscheme.txt', 'r') as f:
	# 	ke=f.readline().strip()
	# 	keyy=f.readline().strip()

	with open(in_filename, 'rb') as infile:
		data=infile.read()
		# print(data)
		# print(type(data))
		# data=b'\x10\x04\xaf\xdd"\x18\x16h\xa4\x9b,\x8d'
		# print(data)
		# print(type(data))
		obj2 = ARC4.new(key)
		with open(out_filename, 'wb') as outfile:
			outfile.write(obj2.decrypt(data))


	return out_filename


#############################################
#generating md5
def file_as_bytes(file):
	with file:
		return file.read()


#Upload structure
def create_main(fname):
	global un,pw
	a=myurl+'/cloud/'+"createfolder/"
	folderdata=dict(username=un,password=pw,folder_name=os.path.basename(fname))
	rr = requests.post(a,data=folderdata)
	data=json.loads(rr.text)
	# print(data) 
	r=requests.get(myurl+"/cloud/synccreate/?username="+un+"&password="+pw+"&parent="+str(os.path.basename(fname)))
	# print(json.loads(r.text))


def create_folder(fname,pname):
	global un,pw
	a=myurl+'/cloud/'+"createfolder/"
	folderdata=dict(username=un,password=pw, parent=os.path.basename(pname), folder_name=os.path.basename(fname))
	rr = requests.post(a,data=folderdata)
	data=json.loads(rr.text)
	# print(data) 

# def upload_file(fname,pname):
# 	a=myurl+'/cloud/'+"upload/"
# 	files={'file_data': open(fname,'rb')}
# 	md5sum=hashlib.md5(file_as_bytes(open(fname, 'rb'))).hexdigest()
# 	folderdata=dict(username=un,password=pw, parent=os.path.basename(pname), name=os.path.basename(fname), md5=md5sum)
# 	rr = requests.post(a, files=files, data=folderdata)
# 	data=json.loads(rr.text)
# 	print(data) 

def upload_file(fname,pname):
	global un,pw
	a=myurl+'/cloud/'+"upload/"
	md5sum=hashlib.md5(file_as_bytes(open(fname,'rb'))).hexdigest()
	# encrypted_file=encAES(fname)
	# un='admin'
	# pw ='admin'
	# encrypted_file=fname
	with open('/170050109proj/170050109spcscheme.txt', 'r') as f:
		schema = f.readline().strip()
		if schema=='AES':
			key=f.readline().strip()
			encrypted_file=encAES(key, fname)
		elif schema=='DES':
			key=f.readline().strip()
			encrypted_file=encDES(key, fname)
			# print(encrypted_file)
		elif schema=="ARC4":
			key=f.readline().strip()
			encrypted_file=encARC(key, fname)

	files={'file_data': open(encrypted_file,'rb')}
	# print(type(files[file_data]))
	folderdata=dict(username=un,password=pw, parent=os.path.basename(pname), name=os.path.basename(fname), md5=md5sum)
	rr = requests.post(a, files=files, data=folderdata)
	data=json.loads(rr.text)
	print(os.path.basename(fname),data['status'])
	os.remove(encrypted_file)


#main upload function
def upload(curr,prev):
	if os.path.isfile(curr):   
		upload_file(curr,prev)

	elif os.path.isdir(curr):
		create_folder(curr,prev)
		for filename in os.listdir(curr):
			upload(curr+"/"+str(filename),curr)


def download(file_id,curr):
	global un,pw
	data=requests.get(myurl+'/cloud/download/?username='+str(un)+'&password='+str(pw)+'&file_id='+str(file_id))
	file=json.loads(data.text)
	if not 'failed' in file:
		# print(file['link'])
		r=requests.get(myurl+'/files/download/?name='+str(file['link']), allow_redirects=True)
		# if file['link'].find('/'):
		# 	filename=file['link'].split('/')[4]
		xx=file['name']

		open(curr+"/"+file['name']+".enc", 'wb').write(r.content)
		with open('/170050109proj/170050109spcscheme.txt', 'r') as f:
			schema = f.readline().strip()
			if schema=='AES':
				key=f.readline().strip()
				# encrypted_file=encAES(key, fname)
				dcypAES(key, curr+"/"+file['name']+".enc",curr+"/"+xx)
			if schema=='DES':
				key=f.readline().strip()
				dcypDES(key,curr+"/"+file['name']+".enc",curr+"/"+xx)
			if schema=="ARC4":
			
				key=f.readline().strip()
				dcypARC(key,curr+"/"+file['name']+".enc",curr+"/"+xx)
		
		os.remove(curr+"/"+file['name']+".enc")
		print(xx,'downloaded')
	else:
		print('Failed')

###################################################
def change_key(p,x,sc):
	m = hashlib.md5()
	m.update(str(x))
	x=m.hexdigest()
	requests.get(myurl+"/cloud/changestatus/?username="+un+"&password="+pw+"&change="+x+"&parent="+str(p)+"&key="+str(x)+"&schema="+str(sc))


def sync_status(p):
	r=requests.get(myurl+"/cloud/syncstatus/?username="+un+"&password="+pw+"&parent="+str(p))
	stat=json.loads(r.text)
	if (stat['status']=='no' or (time.time()-float(stat['time']))>120):
		return True
	else:
		return False

def change_status(p,x):
	requests.get(myurl+"/cloud/changestatus/?username="+un+"&password="+pw+"&change="+x+"&parent="+str(p))

def sync_function(curr,pid):
	# print(curr)
	# print(pid)
	if pid==-1:
		files_req=requests.get(myurl+"/cloud/syncfiles/?username="+un+"&password="+pw+"&folder_name="+str(os.path.basename(curr)))
		folders_req=requests.get(myurl+"/cloud/syncfolders/?username="+un+"&password="+pw+"&folder_name="+str(os.path.basename(curr)))
	else:
		files_req=requests.get(myurl+"/cloud/syncfiles/?username="+un+"&password="+pw+"&folder_name="+str(os.path.basename(curr))+"&parent="+str(pid))
		folders_req=requests.get(myurl+"/cloud/syncfolders/?username="+un+"&password="+pw+"&folder_name="+str(os.path.basename(curr))+"&parent="+str(pid))
	files_list=json.loads(files_req.text)
	folders_list=json.loads(folders_req.text)
	# print(files_list)
	# print(folders_list)
	files_done=[]
	folders_done=[]
	for item in files_list:
		fname=item['name']
		# print(fname)
		if os.path.isfile(curr+'/'+fname):
			md5sum=hashlib.md5(file_as_bytes(open(curr+'/'+fname, 'rb'))).hexdigest()
			if not md5sum==item['md5']:
				# print('check fail')
				# print(fname)
				# ask=input("change spc or pc (1/2): ")
				if ask=='1':
					delete_file(item['id'])
					upload_file(curr+'/'+fname,curr)
				else:
					# print('donwloading check sum fail',fname)
					download(item['id'],curr)
		else:
			# print('downloading not present',fname)
			download(item['id'],curr)
		files_done.append(fname)

	for item in folders_list:
		fname=item['folder_name']
		# print(fname)
		if not os.path.isdir(curr+'/'+fname):
			# print(fname)
			# print('working on it')
			# create_folder(curr+'/'+fname,curr)
			os.mkdir(curr+'/'+fname)
			sync_function(curr+'/'+fname,item['parent'])
			# download_folder(pname+'/'+fname,pname)
		else:
			# print('syncing')
			sync_function(curr+'/'+fname,item['parent'])
		folders_done.append(fname)
	# print(folders_done)
	# print(os.listdir(curr))
	for name in os.listdir(curr):
		# print(os.path.isfile(curr+'/'+name) , name)
		if os.path.isfile(curr+'/'+name):
			if not name in files_done:
				# print('uploading')
				upload_file(curr+'/'+name,curr)
		elif os.path.isdir(curr+'/'+name):
			if not name in folders_done:
				# print('upload function',name)
				upload(curr+'/'+name,curr)


###################################################

def delete_file(id):
	# r=requests.get(myurl+"/cloud/deletefile/?username="+un+"&password="+pw+"&name="+str(name)+"&parent="+str(par))
	r=requests.get(myurl+"/cloud/deletefile/?username="+un+"&password="+pw+"&id="+str(id))
	# print(json.loads(r.text))

def delete_folder(par,name):
	r=requests.get(myurl+"/cloud/deletefolder/?username="+un+"&password="+pw+"&name="+str(name)+"&parent="+str(par))
	# print(json.loads(r.text))
def delete_main(name):
	r=requests.get(myurl+"/cloud/deletemain/?username="+un+"&password="+pw+"&name="+str(name))


###################################################

def status_function(curr,pid,basecurr):
	# print(curr)
	# print(pid)
	if pid==-1:
		files_req=requests.get("http://127.0.0.1:8000/cloud/syncfiles/?username="+un+"&password="+pw+"&folder_name="+str(os.path.basename(curr)))
		folders_req=requests.get("http://127.0.0.1:8000/cloud/syncfolders/?username="+un+"&password="+pw+"&folder_name="+str(os.path.basename(curr)))
	else:
		files_req=requests.get("http://127.0.0.1:8000/cloud/syncfiles/?username="+un+"&password="+pw+"&folder_name="+str(os.path.basename(curr))+"&parent="+str(pid))
		folders_req=requests.get("http://127.0.0.1:8000/cloud/syncfolders/?username="+un+"&password="+pw+"&folder_name="+str(os.path.basename(curr))+"&parent="+str(pid))
	files_list=json.loads(files_req.text)
	folders_list=json.loads(folders_req.text)
	# print(files_list)
	# print(folders_list)
	files_done=[]
	folders_done=[]
	
	for item in files_list:
		fname=item['name']
		# print(fname)
		if os.path.isfile(curr+'/'+fname):
			md5sum=hashlib.md5(file_as_bytes(open(curr+'/'+fname, 'rb'))).hexdigest()
			if not md5sum==item['md5']:
				files_diff.append(basecurr+'/'+fname)
			else:
				files_common.append(basecurr+'/'+fname)
		else:
			files_spc.append(basecurr+'/'+fname)
		files_done.append(fname)

	for item in folders_list:
		fname=item['folder_name']
		# print(fname)
		if not os.path.isdir(curr+'/'+fname):
			files_spc.append('dir : '+basecurr+'/'+fname)
			# status_function(curr+'/'+fname,item['parent'],basecurr+'/'+fname)
		else:
			status_function(curr+'/'+fname,item['parent'],basecurr+'/'+fname)
		folders_done.append(fname)
	# print(folders_done)
	# print(os.listdir(curr))
	for name in os.listdir(curr):
		# print(os.path.isfile(curr+'/'+name) , name)
		if os.path.isfile(curr+'/'+name):
			if not name in files_done:
				files_pc.append(basecurr+'/'+name)
		elif os.path.isdir(curr+'/'+name):
			if not name in folders_done:
				files_pc.append('dir : '+basecurr+'/'+name)



###################################



# with open ('pro/testinginput.txt','a') as f:
global ask
fn=''
ask=1
with open('/170050109proj/170050109spctest.txt','r') as f:
	un=f.readline().strip()
	pw=f.readline().strip()

with open('/170050109proj/170050109spcurl.txt','r') as f:
	myurl=f.readline().strip()

with open('/170050109proj/formycron.txt','r') as f:
	fn=f.readline().strip()
	ask=f.readline().strip()
print(fn)
print(ask)
if not sync_status(os.path.basename(fn)):
	print('Kindly wait for some time')
	sys.exit()
ask=int(ask)
change_status(os.path.basename(fn),'yes')
p = multiprocessing.Process(target=sync_function, name="sync", args=(fn,-1,))
# sync_function(fn,-1)
p.start()
p.join(120)
if p.is_alive():
	p.terminate()
	p.join()
change_status(os.path.basename(fn),'no')


