#!/bin/sh
crontab -r