#!/bin/sh

cd /170050109proj
virtualenv venv
. venv/bin/activate
pip install requests
pip install pycrypto
pip install bs4


pip install --editable .